# BLOOM ✦ Magic at your fingertips.

A mobile-first, browser-based AR experience: real hand tracking (MediaPipe
Hand Landmarker) turns your fingertips into a living particle garden.
Flowers spawn from your fingers, bloom when you open your palm, glow
between a pinch, and trail behind a swipe — all rendered with hand-drawn
Canvas 2D particles (no emoji stickers, no WebGL required).

Everything runs **entirely client-side**. No camera frame is ever sent
anywhere.

## Run it locally

Browsers require a **secure context** (`https://` or `localhost`) for both
camera access and ES module imports, so you can't just double-click
`index.html`. Serve the folder instead, e.g.:

```bash
npx serve .
# or
python3 -m http.server 8080
```

Then open the printed `http://localhost:...` URL — on your phone, use your
computer's LAN IP over HTTPS (or a tunnel like `ngrok`) since mobile
Safari/Chrome also require a secure context for camera access.

## Deploy

This is a static site — no build step. Drag the folder into Netlify, run
`vercel deploy`, or push it to a `gh-pages` branch for GitHub Pages. Just
make sure the host serves it over HTTPS (all three do by default).

## How it works

| File | Responsibility |
|---|---|
| `index.html` | Landing screen + camera experience markup |
| `css/style.css` | Design tokens, layout, glassmorphism UI, animations |
| `js/handTracking.js` | Loads MediaPipe's `HandLandmarker` from its CDN, runs per-frame detection, smooths landmarks (EMA filter), and recognizes open-palm / pinch / swipe gestures |
| `js/particles.js` | Canvas 2D particle system — procedurally draws flowers, sparkles, hearts and butterflies (bezier petals, gradients, glow) rather than emoji |
| `js/landing.js` | The landing page's signature looping bloom animation + ambient floating petals |
| `js/util.js` | Shared math: `object-fit: cover` coordinate mapping, EMA smoothing, small helpers |
| `js/app.js` | Orchestrates everything: camera stream, render loop, gesture → particle wiring, UI (effects/settings panels, capture, recording) |

**Coordinate alignment:** the `<video>` and the transparent particle
`<canvas>` sit inside one wrapper that gets mirrored with a single
`transform: scaleX(-1)`, so both flip together — no manual x-flipping of
landmark math is needed. Because the video is displayed with
`object-fit: cover`, `computeCoverRect()` in `util.js` reproduces that same
crop math so a landmark's normalized position always lands on the correct
on-screen pixel, however the phone is oriented.

**Gestures** (`GestureTracker` in `handTracking.js`):
- **Open palm** — 3+ fingers extended → a bloom burst, then a re-bloom every ~0.9s while held open.
- **Pinch** — thumb/index distance below a hand-size-relative threshold → a glowing flower held at the pinch point; releasing it launches it with the fingers' recent velocity.
- **Swipe** — palm-center speed over a threshold → a flower trail spawned at every fingertip along the motion.

## Customizing

- **Palette / type / spacing** — all defined as CSS custom properties at the top of `css/style.css`.
- **Add or tweak an effect theme** — edit the `THEMES` object in `js/particles.js` (petal count, colors, glow color, shape kind).
- **Particle budget / feel** — `ParticleSystem` is constructed with `maxParticles: 220` in `app.js`; ambient spawn rates are `AMBIENT_TIP_CHANCE` / `AMBIENT_PALM_CHANCE` near the render loop.
- **Detection cost** — `DETECT_INTERVAL_MS` in `app.js` caps MediaPipe inference to ~30fps regardless of display refresh rate; the camera capture resolution requested is 960×720 (`startCameraStream`), a middle ground between clarity and phone GPU/CPU load.

## Browser support

Needs `getUserMedia`, ES modules, WebAssembly, and (for video recording
only) `MediaRecorder` + `canvas.captureStream`. That covers current Chrome
and Safari on Android/iOS and all modern desktop browsers. If the WebGL
delegate MediaPipe prefers isn't available, `handTracking.js` automatically
falls back to its CPU delegate. If `MediaRecorder` isn't supported, the
Photo/Video toggle hides itself and the app stays in photo mode.

## Notes on this build

No reference video was attached to the request this was built from, so the
interaction design (gesture set, bloom timing, easing, particle behavior)
was interpreted from the written brief rather than matched frame-by-frame
to a source clip. If you have the reference clip, the easiest places to
retune the *feel* to match it are the spawn/physics constants in
`ParticleSystem` (`particles.js`) and the gesture thresholds in
`GestureTracker` (`handTracking.js`).
