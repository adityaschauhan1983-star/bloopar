import { HandTracker, GestureTracker, FINGERTIPS } from './handTracking.js';
import { ParticleSystem, THEMES } from './particles.js';
import { LandingScene } from './landing.js';
import { computeCoverRect, mapNormalizedToCover, clamp, rand } from './util.js';

/* ------------------------------------------------------------------ */
/*  DOM references                                                     */
/* ------------------------------------------------------------------ */

const $ = (sel) => document.querySelector(sel);

const screenLanding = $('#screen-landing');
const screenCamera = $('#screen-camera');
const btnEnter = $('#btn-enter');
const landingCanvas = $('#landing-canvas');

const stage = $('#stage');
const video = $('#camera-feed');
const overlayCanvas = $('#overlay-canvas');
const overlayCtx = overlayCanvas.getContext('2d');

const panelPermission = $('#panel-permission');
const panelLoading = $('#panel-loading');
const panelError = $('#panel-error');
const btnGrantCamera = $('#btn-grant-camera');
const btnRetryCamera = $('#btn-retry-camera');
const errorMessage = $('#error-message');

const privacyToast = $('#privacy-toast');
const tutorialText = $('#tutorial-text');
const hintText = $('#hint-text');

const uiLayer = $('#ui-layer');
const btnFlip = $('#btn-flip');
const btnEffects = $('#btn-effects');
const btnSettings = $('#btn-settings');
const btnCapture = $('#btn-capture');
const recTimer = $('#rec-timer');
const modeToggle = $('#mode-toggle');
const effectsPanel = $('#effects-panel');
const settingsPanel = $('#settings-panel');

const previewScreen = $('#preview-screen');
const previewWrap = $('#preview-media-wrap');
const btnSave = $('#btn-save');
const btnRetake = $('#btn-retake');
const flashEl = $('#flash');

/* ------------------------------------------------------------------ */
/*  State                                                              */
/* ------------------------------------------------------------------ */

const state = {
  facingMode: 'user',
  mirror: true,
  mediaStream: null,
  handTracker: new HandTracker(),
  gestureTracker: new GestureTracker(),
  particles: new ParticleSystem({ maxParticles: 220 }),
  densityMult: 1,
  running: false,
  lastDetectAt: 0,
  heldParticles: new Map(), // handKey -> particle
  lastActivityAt: performance.now(),
  captureMode: 'photo', // 'photo' | 'video'
  recorder: null,
  recordedChunks: [],
  recordStartAt: 0,
  recordTimerInterval: null,
  lastPreviewURL: null,
  lastPreviewKind: null,
  handednessKeys: new Map(), // slot index -> stable key
  noHandSince: performance.now(),
  tutorialShown: false
};

/* ------------------------------------------------------------------ */
/*  Landing screen                                                     */
/* ------------------------------------------------------------------ */

const landingScene = new LandingScene(landingCanvas);
landingScene.start();

btnEnter.addEventListener('click', enterExperience);

async function enterExperience() {
  screenLanding.classList.add('leaving');
  markActivity();
  setTimeout(() => {
    screenLanding.classList.add('hidden');
    landingScene.stop();
  }, 950);

  screenCamera.classList.remove('hidden');
  requestAnimationFrame(() => screenCamera.classList.add('active'));

  showPanel(panelPermission);
}

/* ------------------------------------------------------------------ */
/*  Camera permission + stream                                         */
/* ------------------------------------------------------------------ */

btnGrantCamera.addEventListener('click', requestCameraAndStart);
btnRetryCamera.addEventListener('click', requestCameraAndStart);

function showPanel(panel) {
  [panelPermission, panelLoading, panelError].forEach((p) => p.classList.add('hidden'));
  panel.classList.remove('hidden');
}

function hideAllPanels() {
  [panelPermission, panelLoading, panelError].forEach((p) => p.classList.add('hidden'));
}

async function requestCameraAndStart() {
  showPanel(panelLoading);
  try {
    await startCameraStream(state.facingMode);
    await ensureHandTracker();
    hideAllPanels();
    showPrivacyToast();
    startRenderLoop();
    maybeShowTutorial();
  } catch (err) {
    console.error('BLOOM camera/model init failed:', err);
    errorMessage.textContent = describeError(err);
    showPanel(panelError);
  }
}

function describeError(err) {
  if (err && (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError')) {
    return 'Camera access was denied. Please allow camera permission in your browser settings and try again.';
  }
  if (err && err.name === 'NotFoundError') {
    return 'No camera was found on this device.';
  }
  if (err && err.name === 'NotReadableError') {
    return 'Your camera seems to be in use by another app. Close it and try again.';
  }
  return 'Something interrupted the bloom. Please try again.';
}

async function startCameraStream(facingMode) {
  stopCameraStream();
  const constraints = {
    audio: false,
    video: {
      facingMode: { ideal: facingMode },
      width: { ideal: 960 },
      height: { ideal: 720 }
    }
  };
  const stream = await navigator.mediaDevices.getUserMedia(constraints);
  state.mediaStream = stream;
  video.srcObject = stream;
  await video.play().catch(() => {});
  await waitForVideoReady(video);

  state.facingMode = facingMode;
  state.mirror = facingMode === 'user';
  applyMirror();
}

function waitForVideoReady(v) {
  if (v.videoWidth) return Promise.resolve();
  return new Promise((resolve) => {
    v.addEventListener('loadedmetadata', () => resolve(), { once: true });
  });
}

function stopCameraStream() {
  if (state.mediaStream) {
    state.mediaStream.getTracks().forEach((t) => t.stop());
    state.mediaStream = null;
  }
}

function applyMirror() {
  stage.classList.toggle('mirrored', state.mirror);
}

let handTrackerReady = false;
async function ensureHandTracker() {
  if (handTrackerReady) return;
  await state.handTracker.init();
  handTrackerReady = true;
}

/* ------------------------------------------------------------------ */
/*  Privacy toast + tutorial                                           */
/* ------------------------------------------------------------------ */

function showPrivacyToast() {
  privacyToast.classList.add('show');
  setTimeout(() => privacyToast.classList.remove('show'), 3600);
}

function maybeShowTutorial() {
  if (localStorage.getItem('bloom_tutorial_seen')) return;
  runTutorialSequence();
  localStorage.setItem('bloom_tutorial_seen', '1');
}

function runTutorialSequence() {
  const steps = ['Show me your hand ✋', 'Move your fingers…', 'Watch them bloom 🌸'];
  let i = 0;
  const showNext = () => {
    tutorialText.textContent = steps[i];
    tutorialText.classList.add('show');
    setTimeout(() => {
      tutorialText.classList.remove('show');
      i++;
      if (i < steps.length) setTimeout(showNext, 450);
    }, 1750);
  };
  setTimeout(showNext, 600);
}

$('#btn-reset-tutorial').addEventListener('click', () => {
  localStorage.removeItem('bloom_tutorial_seen');
  closePanels();
  runTutorialSequence();
});

/* ------------------------------------------------------------------ */
/*  Activity / idle UI fade                                            */
/* ------------------------------------------------------------------ */

function markActivity() {
  state.lastActivityAt = performance.now();
  uiLayer.classList.remove('idle');
}

['pointerdown', 'pointermove', 'touchstart', 'keydown'].forEach((evt) => {
  screenCamera.addEventListener(evt, markActivity, { passive: true });
});

setInterval(() => {
  if (performance.now() - state.lastActivityAt > 4200 && !effectsPanel.classList.contains('open') && !settingsPanel.classList.contains('open')) {
    uiLayer.classList.add('idle');
  }
}, 500);

/* ------------------------------------------------------------------ */
/*  Effects panel                                                      */
/* ------------------------------------------------------------------ */

function buildEffectsPanel() {
  const list = $('#effects-list');
  list.innerHTML = '';
  Object.entries(THEMES).forEach(([key, theme]) => {
    const btn = document.createElement('button');
    btn.className = 'effect-option' + (key === state.particles.themeKey ? ' active' : '');
    btn.dataset.key = key;
    btn.innerHTML = `<span class="emoji">${theme.emoji}</span><span>${theme.label}</span>`;
    btn.addEventListener('click', () => {
      state.particles.setTheme(key);
      list.querySelectorAll('.effect-option').forEach((el) => el.classList.remove('active'));
      btn.classList.add('active');
      markActivity();
    });
    list.appendChild(btn);
  });
}
buildEffectsPanel();

function closePanels() {
  effectsPanel.classList.remove('open');
  settingsPanel.classList.remove('open');
}

btnEffects.addEventListener('click', () => {
  const willOpen = !effectsPanel.classList.contains('open');
  closePanels();
  if (willOpen) effectsPanel.classList.add('open');
  markActivity();
});

btnSettings.addEventListener('click', () => {
  const willOpen = !settingsPanel.classList.contains('open');
  closePanels();
  if (willOpen) settingsPanel.classList.add('open');
  markActivity();
});

document.addEventListener('click', (e) => {
  if (!effectsPanel.contains(e.target) && e.target !== btnEffects && !btnEffects.contains(e.target)) {
    effectsPanel.classList.remove('open');
  }
  if (!settingsPanel.contains(e.target) && e.target !== btnSettings && !btnSettings.contains(e.target)) {
    settingsPanel.classList.remove('open');
  }
});

/* ------------------------------------------------------------------ */
/*  Settings panel                                                     */
/* ------------------------------------------------------------------ */

const switchMirror = $('#switch-mirror');
const switchTrail = $('#switch-trail');
const densityButtons = document.querySelectorAll('.density-row button');

switchMirror.addEventListener('click', () => {
  state.mirror = !state.mirror;
  switchMirror.classList.toggle('on', state.mirror);
  applyMirror();
  markActivity();
});

let trailsEnabled = true;
switchTrail.addEventListener('click', () => {
  trailsEnabled = !trailsEnabled;
  switchTrail.classList.toggle('on', trailsEnabled);
  markActivity();
});

densityButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    densityButtons.forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    const map = { low: 0.5, normal: 1, high: 1.7 };
    state.densityMult = map[btn.dataset.density] ?? 1;
    markActivity();
  });
});

/* ------------------------------------------------------------------ */
/*  Camera flip                                                        */
/* ------------------------------------------------------------------ */

btnFlip.addEventListener('click', async () => {
  markActivity();
  btnFlip.disabled = true;
  const next = state.facingMode === 'user' ? 'environment' : 'user';
  try {
    await startCameraStream(next);
    switchMirror.classList.toggle('on', state.mirror);
    state.handednessKeys.clear();
    state.particles.clear();
  } catch (err) {
    console.error('BLOOM camera flip failed:', err);
  } finally {
    btnFlip.disabled = false;
  }
});

/* ------------------------------------------------------------------ */
/*  Capture mode toggle (photo / video)                                */
/* ------------------------------------------------------------------ */

const recordingSupported = (() => {
  try {
    return !!(overlayCanvas.captureStream && window.MediaRecorder &&
      (MediaRecorder.isTypeSupported('video/webm;codecs=vp9') ||
       MediaRecorder.isTypeSupported('video/webm;codecs=vp8') ||
       MediaRecorder.isTypeSupported('video/webm')));
  } catch { return false; }
})();

if (!recordingSupported) modeToggle.classList.add('hidden');

modeToggle.querySelectorAll('button').forEach((btn) => {
  btn.addEventListener('click', () => {
    modeToggle.querySelectorAll('button').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    state.captureMode = btn.dataset.mode;
    markActivity();
  });
});

/* ------------------------------------------------------------------ */
/*  Render loop: hand tracking -> gestures -> particles                */
/* ------------------------------------------------------------------ */

function resizeOverlay() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = stage.clientWidth;
  const h = stage.clientHeight;
  overlayCanvas.width = w * dpr;
  overlayCanvas.height = h * dpr;
  overlayCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
window.addEventListener('resize', resizeOverlay);
resizeOverlay();

function startRenderLoop() {
  if (state.running) return;
  state.running = true;
  let lastT = performance.now();
  const loop = (now) => {
    if (!state.running) return;
    const dt = Math.min((now - lastT) / 1000, 0.05);
    lastT = now;
    frame(now, dt);
    requestAnimationFrame(loop);
  };
  requestAnimationFrame(loop);
}

const DETECT_INTERVAL_MS = 33; // ~30fps cap on MediaPipe inference for perf

function frame(now, dt) {
  resizeIfNeeded();

  let hands = [];
  if (now - state.lastDetectAt >= DETECT_INTERVAL_MS && video.videoWidth) {
    state.lastDetectAt = now;
    hands = state.handTracker.detect(video, now);
  } else {
    hands = state._lastHands || [];
  }
  state._lastHands = hands;

  overlayCtx.clearRect(0, 0, stage.clientWidth, stage.clientHeight);

  if (hands.length === 0) {
    if (now - state.noHandSince > 700) {
      hintText.classList.add('show');
    }
  } else {
    state.noHandSince = now;
    hintText.classList.remove('show');
    markHandActivity();
  }

  const cover = computeCoverRect(video.videoWidth, video.videoHeight, stage.clientWidth, stage.clientHeight);
  const seenKeys = new Set();

  hands.forEach((hand, idx) => {
    const key = `${idx}-${hand.handedness}`;
    seenKeys.add(key);
    processHand(key, hand, cover, now, dt);
  });

  // release/cleanup held particles for hands that disappeared
  for (const [key, particle] of state.heldParticles) {
    if (!seenKeys.has(key)) {
      state.particles.releaseHeld(particle, rand(-20, 20), rand(-40, -10));
      state.heldParticles.delete(key);
      state.gestureTracker.reset(key);
    }
  }

  state.particles.update(dt);
  state.particles.draw(overlayCtx);
}

function markHandActivity() {
  // presence of a hand counts as activity so the UI doesn't fade while playing
  state.lastActivityAt = performance.now();
}

let lastStageSize = { w: 0, h: 0 };
function resizeIfNeeded() {
  const w = stage.clientWidth, h = stage.clientHeight;
  if (w !== lastStageSize.w || h !== lastStageSize.h) {
    lastStageSize = { w, h };
    resizeOverlay();
  }
}

function toScreenXY(landmark, cover) {
  return mapNormalizedToCover(landmark.x, landmark.y, video.videoWidth, video.videoHeight, cover, stage.clientWidth, stage.clientHeight);
}

const AMBIENT_TIP_CHANCE = 0.05;
const AMBIENT_PALM_CHANCE = 0.02;

function processHand(key, hand, cover, now, dt) {
  const lm = hand.landmarks;
  const gesture = state.gestureTracker.update(key, hand, now);

  // ambient particles drifting from fingertips
  for (const tipIdx of FINGERTIPS) {
    if (Math.random() < AMBIENT_TIP_CHANCE * state.densityMult) {
      const pt = toScreenXY(lm[tipIdx], cover);
      if (pt.visible) state.particles.spawnBloom(pt.x, pt.y, { sizeMin: 10, sizeMax: 22, life: 2200, spread: 40 });
    }
  }
  if (Math.random() < AMBIENT_PALM_CHANCE * state.densityMult) {
    const p = toScreenXY({ x: gesture.palm.x, y: gesture.palm.y }, cover);
    if (p.visible) state.particles.spawnBloom(p.x, p.y, { sizeMin: 16, sizeMax: 28, life: 2600, spread: 30 });
  }

  // open palm -> bloom burst
  if (gesture.openBurst) {
    const p = toScreenXY({ x: gesture.palm.x, y: gesture.palm.y }, cover);
    if (p.visible) state.particles.spawnBurst(p.x, p.y, 10 + Math.round(4 * state.densityMult));
  }

  // pinch -> held glowing flower between thumb & index
  if (gesture.pinchStart) {
    const p = toScreenXY(gesture.pinchMid, cover);
    const particle = state.particles.spawnHeld(p.x, p.y);
    state.heldParticles.set(key, particle);
  } else if (gesture.isPinched && state.heldParticles.has(key)) {
    const p = toScreenXY(gesture.pinchMid, cover);
    state.particles.updateHeld(state.heldParticles.get(key), p.x, p.y, dt);
  } else if (gesture.pinchEnd && state.heldParticles.has(key)) {
    const particle = state.heldParticles.get(key);
    const p = toScreenXY(gesture.pinchMid, cover);
    const vx = (p.x - particle.x) / Math.max(dt, 0.016);
    const vy = (p.y - particle.y) / Math.max(dt, 0.016);
    state.particles.releaseHeld(particle, clamp(vx, -220, 220), clamp(vy, -220, 220));
    state.heldParticles.delete(key);
  }

  // swipe -> flower trail along movement, at every fingertip
  if (gesture.swipe && trailsEnabled) {
    for (const tipIdx of FINGERTIPS) {
      const pt = toScreenXY(lm[tipIdx], cover);
      if (pt.visible) state.particles.spawnTrail(pt.x, pt.y, gesture.swipe.dirX, gesture.swipe.dirY);
    }
  }
}

/* ------------------------------------------------------------------ */
/*  Capture: photo + video                                             */
/* ------------------------------------------------------------------ */

btnCapture.addEventListener('click', () => {
  markActivity();
  if (state.captureMode === 'video' && recordingSupported) {
    toggleRecording();
  } else {
    takePhoto();
  }
});

function fireFlash() {
  flashEl.classList.remove('fire');
  void flashEl.offsetWidth; // restart animation
  flashEl.classList.add('fire');
}

function buildCompositeCanvas() {
  const w = stage.clientWidth, h = stage.clientHeight;
  const canvas = document.createElement('canvas');
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  ctx.save();
  if (state.mirror) {
    ctx.translate(w, 0);
    ctx.scale(-1, 1);
  }
  const cover = computeCoverRect(video.videoWidth, video.videoHeight, w, h);
  ctx.drawImage(video, cover.sx, cover.sy, cover.sw, cover.sh, 0, 0, w, h);
  ctx.drawImage(overlayCanvas, 0, 0, overlayCanvas.width, overlayCanvas.height, 0, 0, w, h);
  ctx.restore();
  return canvas;
}

function takePhoto() {
  fireFlash();
  const canvas = buildCompositeCanvas();
  canvas.toBlob((blob) => {
    if (!blob) return;
    showPreview(URL.createObjectURL(blob), 'photo');
  }, 'image/png');
}

function toggleRecording() {
  if (state.recorder && state.recorder.state === 'recording') {
    state.recorder.stop();
    return;
  }
  startRecording();
}

function startRecording() {
  const w = stage.clientWidth, h = stage.clientHeight;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const recordCanvas = document.createElement('canvas');
  recordCanvas.width = w * dpr;
  recordCanvas.height = h * dpr;
  const rctx = recordCanvas.getContext('2d');
  rctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  let recording = true;
  const drawFrame = () => {
    if (!recording) return;
    rctx.save();
    if (state.mirror) {
      rctx.translate(w, 0);
      rctx.scale(-1, 1);
    }
    const cover = computeCoverRect(video.videoWidth, video.videoHeight, w, h);
    rctx.drawImage(video, cover.sx, cover.sy, cover.sw, cover.sh, 0, 0, w, h);
    rctx.drawImage(overlayCanvas, 0, 0, overlayCanvas.width, overlayCanvas.height, 0, 0, w, h);
    rctx.restore();
    requestAnimationFrame(drawFrame);
  };
  drawFrame();

  const stream = recordCanvas.captureStream(30);
  const mimeType = ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm']
    .find((t) => MediaRecorder.isTypeSupported(t)) || '';
  const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
  state.recordedChunks = [];
  recorder.ondataavailable = (e) => { if (e.data.size) state.recordedChunks.push(e.data); };
  recorder.onstop = () => {
    recording = false;
    stopRecTimer();
    btnCapture.classList.remove('recording');
    const blob = new Blob(state.recordedChunks, { type: 'video/webm' });
    showPreview(URL.createObjectURL(blob), 'video');
  };
  recorder.start();
  state.recorder = recorder;
  btnCapture.classList.add('recording');
  startRecTimer();
}

function startRecTimer() {
  state.recordStartAt = performance.now();
  recTimer.classList.add('live');
  state.recordTimerInterval = setInterval(() => {
    const s = Math.floor((performance.now() - state.recordStartAt) / 1000);
    const mm = String(Math.floor(s / 60)).padStart(2, '0');
    const ss = String(s % 60).padStart(2, '0');
    recTimer.textContent = `${mm}:${ss}`;
  }, 250);
}

function stopRecTimer() {
  clearInterval(state.recordTimerInterval);
  recTimer.classList.remove('live');
  recTimer.textContent = '';
}

/* ------------------------------------------------------------------ */
/*  Preview screen                                                     */
/* ------------------------------------------------------------------ */

function showPreview(url, kind) {
  state.lastPreviewURL = url;
  state.lastPreviewKind = kind;
  previewWrap.innerHTML = '';
  if (kind === 'photo') {
    const img = document.createElement('img');
    img.src = url;
    previewWrap.appendChild(img);
  } else {
    const vid = document.createElement('video');
    vid.src = url;
    vid.controls = true;
    vid.autoplay = true;
    vid.loop = true;
    vid.playsInline = true;
    previewWrap.appendChild(vid);
  }
  previewScreen.classList.add('show');
}

function closePreview() {
  previewScreen.classList.remove('show');
  previewWrap.innerHTML = '';
  if (state.lastPreviewURL) {
    URL.revokeObjectURL(state.lastPreviewURL);
    state.lastPreviewURL = null;
  }
}

btnRetake.addEventListener('click', closePreview);

btnSave.addEventListener('click', () => {
  if (!state.lastPreviewURL) return;
  const a = document.createElement('a');
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  a.href = state.lastPreviewURL;
  a.download = state.lastPreviewKind === 'photo' ? `bloom-${ts}.png` : `bloom-${ts}.webm`;
  document.body.appendChild(a);
  a.click();
  a.remove();
});

/* ------------------------------------------------------------------ */
/*  Visibility handling                                                */
/* ------------------------------------------------------------------ */

document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    video.pause?.();
  } else if (state.mediaStream) {
    video.play?.().catch(() => {});
  }
});
