// util.js — small shared helpers, no dependencies.

export function clamp(v, min, max) {
  return v < min ? min : v > max ? max : v;
}

export function lerp(a, b, t) {
  return a + (b - a) * t;
}

export function dist(ax, ay, bx, by) {
  return Math.hypot(ax - bx, ay - by);
}

export function rand(min, max) {
  return min + Math.random() * (max - min);
}

export function pick(arr) {
  return arr[(Math.random() * arr.length) | 0];
}

/**
 * Computes the source crop rectangle (in the source media's own pixel
 * space) that an `object-fit: cover` render of `srcW x srcH` into a
 * `dstW x dstH` box would show. Used to keep hand-landmark coordinates
 * and photo/video capture perfectly aligned with what's visually on
 * screen, since the <video> element itself is cropped by CSS cover.
 */
export function computeCoverRect(srcW, srcH, dstW, dstH) {
  const srcRatio = srcW / srcH;
  const dstRatio = dstW / dstH;
  let sw, sh, sx, sy;
  if (srcRatio > dstRatio) {
    // source is relatively wider than destination -> crop left/right
    sh = srcH;
    sw = srcH * dstRatio;
    sx = (srcW - sw) / 2;
    sy = 0;
  } else {
    // source is relatively taller -> crop top/bottom
    sw = srcW;
    sh = srcW / dstRatio;
    sx = 0;
    sy = (srcH - sh) / 2;
  }
  return { sx, sy, sw, sh };
}

/** Maps a normalized (0..1) landmark point, relative to the FULL source
 * frame, into destination pixel space that has been cropped with
 * computeCoverRect. Returns null if the point falls outside the visible
 * crop (rare, only near extreme edges). */
export function mapNormalizedToCover(nx, ny, srcW, srcH, cover, dstW, dstH) {
  const px = nx * srcW;
  const py = ny * srcH;
  const relX = (px - cover.sx) / cover.sw;
  const relY = (py - cover.sy) / cover.sh;
  return { x: relX * dstW, y: relY * dstH, visible: relX >= -0.05 && relX <= 1.05 && relY >= -0.05 && relY <= 1.05 };
}

/** Simple exponential-moving-average smoother for a flat array of numbers
 * (e.g. 21 landmarks * 2 coords). Call .smooth(rawArray) every frame. */
export class EmaSmoother {
  constructor(alpha = 0.45) {
    this.alpha = alpha;
    this.state = null;
  }
  reset() {
    this.state = null;
  }
  smooth(raw) {
    if (!this.state || this.state.length !== raw.length) {
      this.state = raw.slice();
      return this.state.slice();
    }
    const a = this.alpha;
    for (let i = 0; i < raw.length; i++) {
      this.state[i] = this.state[i] * (1 - a) + raw[i] * a;
    }
    return this.state.slice();
  }
}

/** Tiny publish/subscribe used to decouple modules. */
export class Emitter {
  constructor() { this._listeners = {}; }
  on(evt, fn) {
    (this._listeners[evt] ||= []).push(fn);
    return () => this.off(evt, fn);
  }
  off(evt, fn) {
    if (!this._listeners[evt]) return;
    this._listeners[evt] = this._listeners[evt].filter((f) => f !== fn);
  }
  emit(evt, payload) {
    (this._listeners[evt] || []).forEach((fn) => fn(payload));
  }
}

export function throttle(fn, ms) {
  let last = 0;
  return (...args) => {
    const now = performance.now();
    if (now - last >= ms) {
      last = now;
      fn(...args);
    }
  };
}
