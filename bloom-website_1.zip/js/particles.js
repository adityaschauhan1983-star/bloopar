// particles.js — a small, dependency-free particle system that draws
// procedural flower/sparkle/heart/butterfly shapes with canvas paths
// (never emoji glyphs), so every bloom can be sized, rotated, colored
// and animated smoothly.

import { rand, pick, clamp } from './util.js';

/* -------------------------------------------------------------------- */
/*  Theme definitions                                                    */
/* -------------------------------------------------------------------- */

function drawPetalFlower(ctx, size, { petals, colorInner, colorOuter, colorCenter, petalShape = 'round' }) {
  const petalLen = size * 0.62;
  const petalWidth = size * (petalShape === 'thin' ? 0.34 : 0.5);

  for (let i = 0; i < petals; i++) {
    const angle = (Math.PI * 2 * i) / petals;
    ctx.save();
    ctx.rotate(angle);
    const grad = ctx.createLinearGradient(0, 0, 0, -petalLen);
    grad.addColorStop(0, colorInner);
    grad.addColorStop(1, colorOuter);
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.bezierCurveTo(
      petalWidth, -petalLen * 0.28,
      petalWidth * 0.55, -petalLen * 0.92,
      0, -petalLen
    );
    ctx.bezierCurveTo(
      -petalWidth * 0.55, -petalLen * 0.92,
      -petalWidth, -petalLen * 0.28,
      0, 0
    );
    ctx.fill();
    ctx.restore();
  }

  // center
  const centerR = size * 0.16;
  const cg = ctx.createRadialGradient(0, 0, 0, 0, 0, centerR);
  cg.addColorStop(0, colorCenter);
  cg.addColorStop(1, colorCenter + '00');
  ctx.fillStyle = colorCenter;
  ctx.beginPath();
  ctx.arc(0, 0, centerR, 0, Math.PI * 2);
  ctx.fill();
}

function drawSparkle(ctx, size, { color }) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(0, -size);
  ctx.quadraticCurveTo(size * 0.12, -size * 0.12, size, 0);
  ctx.quadraticCurveTo(size * 0.12, size * 0.12, 0, size);
  ctx.quadraticCurveTo(-size * 0.12, size * 0.12, -size, 0);
  ctx.quadraticCurveTo(-size * 0.12, -size * 0.12, 0, -size);
  ctx.closePath();
  ctx.fill();

  ctx.save();
  ctx.rotate(Math.PI / 4);
  ctx.globalAlpha *= 0.55;
  const s2 = size * 0.55;
  ctx.beginPath();
  ctx.moveTo(0, -s2);
  ctx.quadraticCurveTo(s2 * 0.12, -s2 * 0.12, s2, 0);
  ctx.quadraticCurveTo(s2 * 0.12, s2 * 0.12, 0, s2);
  ctx.quadraticCurveTo(-s2 * 0.12, s2 * 0.12, -s2, 0);
  ctx.quadraticCurveTo(-s2 * 0.12, -s2 * 0.12, 0, -s2);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawHeart(ctx, size, { color }) {
  const s = size * 0.62;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(0, s * 0.35);
  ctx.bezierCurveTo(-s, -s * 0.5, -s * 0.4, -s * 1.15, 0, -s * 0.4);
  ctx.bezierCurveTo(s * 0.4, -s * 1.15, s, -s * 0.5, 0, s * 0.35);
  ctx.closePath();
  ctx.fill();
}

function drawButterfly(ctx, size, { color, flutter }) {
  const wingScale = 0.75 + Math.sin(flutter) * 0.35;
  ctx.save();
  ctx.scale(wingScale, 1);
  ctx.fillStyle = color;
  ctx.globalAlpha *= 0.92;
  [1, -1].forEach((side) => {
    ctx.beginPath();
    ctx.ellipse(side * size * 0.34, -size * 0.18, size * 0.36, size * 0.46, side * 0.35, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(side * size * 0.28, size * 0.28, size * 0.24, size * 0.3, side * 0.2, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.restore();
  ctx.fillStyle = 'rgba(20,14,20,0.6)';
  ctx.fillRect(-size * 0.02, -size * 0.42, size * 0.04, size * 0.78);
}

export const THEMES = {
  sakura: {
    label: 'Sakura', emoji: '🌸',
    kind: 'flower',
    palette: { colorInner: '#ffd9e8', colorOuter: '#f3a6c4', colorCenter: '#e8c468' },
    opts: { petals: 5, petalShape: 'round' },
    glow: 'rgba(243,166,196,0.55)'
  },
  daisy: {
    label: 'Daisy', emoji: '🌼',
    kind: 'flower',
    palette: { colorInner: '#fffaf0', colorOuter: '#f7f1ea', colorCenter: '#f5c242' },
    opts: { petals: 10, petalShape: 'thin' },
    glow: 'rgba(247,241,234,0.5)'
  },
  tropical: {
    label: 'Tropical', emoji: '🌺',
    kind: 'flower',
    palette: { colorInner: '#ffb37a', colorOuter: '#ff5c6c', colorCenter: '#c81d45' },
    opts: { petals: 6, petalShape: 'round' },
    glow: 'rgba(255,92,108,0.5)'
  },
  stardust: {
    label: 'Stardust', emoji: '✨',
    kind: 'sparkle',
    palette: { color: '#fff6d8' },
    opts: {},
    glow: 'rgba(232,196,104,0.6)'
  },
  love: {
    label: 'Love', emoji: '❤️',
    kind: 'heart',
    palette: { color: '#ff6b84' },
    opts: {},
    glow: 'rgba(255,107,132,0.5)'
  },
  butterfly: {
    label: 'Butterfly', emoji: '🦋',
    kind: 'butterfly',
    palette: { color: '#8e7cff' },
    opts: {},
    glow: 'rgba(142,124,255,0.5)'
  },
  dream: {
    label: 'Dream Mix', emoji: '🌈',
    kind: 'mix',
    palette: {},
    opts: {},
    glow: 'rgba(255,217,232,0.5)'
  }
};

const MIX_KEYS = ['sakura', 'daisy', 'tropical', 'stardust', 'love', 'butterfly'];

function resolveThemeKey(themeKey) {
  if (themeKey !== 'dream') return themeKey;
  return pick(MIX_KEYS);
}

/* -------------------------------------------------------------------- */
/*  Particle                                                             */
/* -------------------------------------------------------------------- */

let uid = 0;

class Particle {
  constructor(opts) {
    this.id = uid++;
    Object.assign(this, opts);
    this.age = 0;
    this.flutter = rand(0, Math.PI * 2);
  }

  update(dt) {
    this.age += dt;
    const t = this.age / this.maxLife;
    if (t >= 1) return false;

    // gentle breeze sway + upward buoyancy
    this.swayPhase += dt * this.swaySpeed;
    const sway = Math.sin(this.swayPhase) * this.swayAmp;

    this.x += (this.vx + sway) * dt;
    this.y += this.vy * dt;
    this.vy += this.buoyancy * dt; // negative buoyancy = drifts upward, decelerating

    this.vx *= this.drag;
    this.vy *= this.drag;

    this.rotation += this.rotationSpeed * dt;
    this.flutter += dt * 6;

    // scale pulse: quick fade/scale in, hold, fade/scale out
    const inT = clamp(t / this.fadeInFrac, 0, 1);
    const outT = clamp((t - (1 - this.fadeOutFrac)) / this.fadeOutFrac, 0, 1);
    this.opacity = Math.min(easeOutCubic(inT), 1 - easeInCubic(outT)) * this.baseOpacity;
    this.scale = 0.4 + 0.6 * easeOutBack(Math.min(inT * 1.3, 1)) * (1 - 0.15 * easeInCubic(outT));

    return true;
  }

  draw(ctx) {
    if (this.opacity <= 0.001) return;
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);
    ctx.scale(this.scale, this.scale);
    ctx.globalAlpha = this.opacity;

    if (this.glow) {
      ctx.shadowColor = this.glow;
      ctx.shadowBlur = this.size * 0.9;
    }

    const t = THEMES[this.themeKey];
    if (t.kind === 'flower') {
      drawPetalFlower(ctx, this.size, { ...t.palette, ...t.opts });
    } else if (t.kind === 'sparkle') {
      drawSparkle(ctx, this.size, t.palette);
    } else if (t.kind === 'heart') {
      drawHeart(ctx, this.size, t.palette);
    } else if (t.kind === 'butterfly') {
      drawButterfly(ctx, this.size, { ...t.palette, flutter: this.flutter });
    }
    ctx.restore();
  }
}

function easeOutCubic(t) { return 1 - Math.pow(1 - t, 3); }
function easeInCubic(t) { return t * t * t; }
function easeOutBack(t) {
  const c1 = 1.5, c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
}

/* -------------------------------------------------------------------- */
/*  System                                                               */
/* -------------------------------------------------------------------- */

export class ParticleSystem {
  constructor({ maxParticles = 220 } = {}) {
    this.particles = [];
    this.maxParticles = maxParticles;
    this.themeKey = 'sakura';
  }

  setTheme(key) {
    if (THEMES[key]) this.themeKey = key;
  }

  setDensity(mult) {
    this.densityMult = mult;
  }

  get count() { return this.particles.length; }

  /** spawn an ambient bloom near a point, drifting up and outward */
  spawnBloom(x, y, { sizeMin = 14, sizeMax = 30, life = 2600, spread = 60, themeKey } = {}) {
    if (this.particles.length >= this.maxParticles) return;
    const key = resolveThemeKey(themeKey || this.themeKey);
    const angle = rand(0, Math.PI * 2);
    const speed = rand(6, spread) / 1000;
    this.particles.push(new Particle({
      themeKey: key,
      x, y,
      vx: Math.cos(angle) * speed * 40,
      vy: Math.sin(angle) * speed * 40 - rand(14, 30),
      buoyancy: -rand(10, 22),
      drag: 0.986,
      swayPhase: rand(0, Math.PI * 2),
      swaySpeed: rand(0.8, 1.6),
      swayAmp: rand(6, 18),
      size: rand(sizeMin, sizeMax),
      rotation: rand(0, Math.PI * 2),
      rotationSpeed: rand(-1.1, 1.1),
      maxLife: life + rand(-300, 400),
      fadeInFrac: 0.16,
      fadeOutFrac: 0.42,
      baseOpacity: rand(0.78, 1),
      glow: THEMES[key].glow
    }));
  }

  /** small quick particle for movement trails */
  spawnTrail(x, y, dirX, dirY, themeKey) {
    if (this.particles.length >= this.maxParticles) return;
    const key = resolveThemeKey(themeKey || this.themeKey);
    this.particles.push(new Particle({
      themeKey: key,
      x, y,
      vx: -dirX * rand(4, 12) + rand(-8, 8),
      vy: -dirY * rand(4, 12) - rand(4, 14),
      buoyancy: -rand(6, 14),
      drag: 0.98,
      swayPhase: rand(0, Math.PI * 2),
      swaySpeed: rand(1, 2),
      swayAmp: rand(3, 9),
      size: rand(7, 15),
      rotation: rand(0, Math.PI * 2),
      rotationSpeed: rand(-1.6, 1.6),
      maxLife: rand(650, 1100),
      fadeInFrac: 0.1,
      fadeOutFrac: 0.55,
      baseOpacity: rand(0.6, 0.9),
      glow: THEMES[key].glow
    }));
  }

  /** big radial burst used for the open-palm gesture */
  spawnBurst(x, y, count, themeKey) {
    for (let i = 0; i < count; i++) {
      if (this.particles.length >= this.maxParticles) break;
      const key = resolveThemeKey(themeKey || this.themeKey);
      const angle = (Math.PI * 2 * i) / count + rand(-0.25, 0.25);
      const speed = rand(50, 150);
      this.particles.push(new Particle({
        themeKey: key,
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - rand(10, 40),
        buoyancy: -rand(14, 30),
        drag: 0.965,
        swayPhase: rand(0, Math.PI * 2),
        swaySpeed: rand(0.8, 1.6),
        swayAmp: rand(8, 20),
        size: rand(16, 34),
        rotation: rand(0, Math.PI * 2),
        rotationSpeed: rand(-1.4, 1.4),
        maxLife: rand(1800, 2800),
        fadeInFrac: 0.12,
        fadeOutFrac: 0.45,
        baseOpacity: rand(0.85, 1),
        glow: THEMES[key].glow
      }));
    }
  }

  /** persistent particle that follows a pinch until released; returns handle */
  spawnHeld(x, y, themeKey) {
    const key = resolveThemeKey(themeKey || this.themeKey);
    const p = new Particle({
      themeKey: key,
      x, y,
      vx: 0, vy: 0,
      buoyancy: 0,
      drag: 1,
      swayPhase: 0, swaySpeed: 0, swayAmp: 0,
      size: 4,
      rotation: rand(0, Math.PI * 2),
      rotationSpeed: rand(-0.6, 0.6),
      maxLife: 999999,
      fadeInFrac: 0.001,
      fadeOutFrac: 0.9999,
      baseOpacity: 1,
      glow: THEMES[key].glow,
      held: true,
      growSize: 30
    });
    // grow quickly to target size, held particles skip the normal life curve
    p.opacity = 1;
    p.scale = 1;
    this.particles.push(p);
    return p;
  }

  updateHeld(p, x, y, dt) {
    p.x = x; p.y = y;
    p.size += (p.growSize - p.size) * Math.min(dt * 6, 1);
    p.rotation += p.rotationSpeed * dt;
    p.flutter += dt * 6;
  }

  releaseHeld(p, vx, vy) {
    p.held = false;
    p.vx = vx; p.vy = vy - 20;
    p.buoyancy = -rand(12, 24);
    p.drag = 0.975;
    p.swayPhase = rand(0, Math.PI * 2);
    p.swaySpeed = rand(0.9, 1.6);
    p.swayAmp = rand(8, 16);
    p.maxLife = rand(1600, 2400);
    p.age = 0;
    p.fadeInFrac = 0.05;
    p.fadeOutFrac = 0.5;
    p.baseOpacity = 1;
  }

  removeHeld(p) {
    const i = this.particles.indexOf(p);
    if (i >= 0) this.particles.splice(i, 1);
  }

  update(dt) {
    this.particles = this.particles.filter((p) => p.held || p.update(dt));
  }

  draw(ctx) {
    for (const p of this.particles) p.draw(ctx);
  }

  clear() {
    this.particles.length = 0;
  }
}
