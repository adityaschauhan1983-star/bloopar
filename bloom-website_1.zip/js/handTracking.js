// handTracking.js — wraps Google's MediaPipe Tasks Vision HandLandmarker.
// Loads the model straight from Google's CDN/model store; everything
// runs locally in the browser (no frames ever leave the device).

import { EmaSmoother, dist } from './util.js';

const VISION_WASM_URL =
  'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm';
const VISION_BUNDLE_URL =
  'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/vision_bundle.mjs';
const MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';

// Landmark index reference (MediaPipe Hands topology)
export const LM = {
  WRIST: 0,
  THUMB_CMC: 1, THUMB_MCP: 2, THUMB_IP: 3, THUMB_TIP: 4,
  INDEX_MCP: 5, INDEX_PIP: 6, INDEX_DIP: 7, INDEX_TIP: 8,
  MIDDLE_MCP: 9, MIDDLE_PIP: 10, MIDDLE_DIP: 11, MIDDLE_TIP: 12,
  RING_MCP: 13, RING_PIP: 14, RING_DIP: 15, RING_TIP: 16,
  PINKY_MCP: 17, PINKY_PIP: 18, PINKY_DIP: 19, PINKY_TIP: 20
};

export const FINGERTIPS = [LM.THUMB_TIP, LM.INDEX_TIP, LM.MIDDLE_TIP, LM.RING_TIP, LM.PINKY_TIP];

const FINGER_CHAINS = [
  [LM.INDEX_MCP, LM.INDEX_PIP, LM.INDEX_TIP],
  [LM.MIDDLE_MCP, LM.MIDDLE_PIP, LM.MIDDLE_TIP],
  [LM.RING_MCP, LM.RING_PIP, LM.RING_TIP],
  [LM.PINKY_MCP, LM.PINKY_PIP, LM.PINKY_TIP]
];

export class HandTracker {
  constructor() {
    this.landmarker = null;
    this.smoothers = new Map(); // handIndex -> EmaSmoother
    this.lastSeenAt = new Map();
    this.ready = false;
  }

  async init() {
    const { HandLandmarker, FilesetResolver } = await import(VISION_BUNDLE_URL);
    const vision = await FilesetResolver.forVisionTasks(VISION_WASM_URL);

    const baseOptions = {
      modelAssetPath: MODEL_URL
    };

    try {
      this.landmarker = await HandLandmarker.createFromOptions(vision, {
        baseOptions: { ...baseOptions, delegate: 'GPU' },
        runningMode: 'VIDEO',
        numHands: 2,
        minHandDetectionConfidence: 0.55,
        minHandPresenceConfidence: 0.5,
        minTrackingConfidence: 0.5
      });
    } catch (err) {
      // GPU delegate isn't available on every device/browser — fall back to CPU.
      this.landmarker = await HandLandmarker.createFromOptions(vision, {
        baseOptions: { ...baseOptions, delegate: 'CPU' },
        runningMode: 'VIDEO',
        numHands: 2,
        minHandDetectionConfidence: 0.55,
        minHandPresenceConfidence: 0.5,
        minTrackingConfidence: 0.5
      });
    }

    this.ready = true;
  }

  /** Runs detection for one video frame. Returns an array of hand results:
   *  [{ landmarks: [{x,y,z}×21] (smoothed, normalized 0..1), handedness }]
   */
  detect(video, timestampMs) {
    if (!this.ready || !video.videoWidth) return [];
    const result = this.landmarker.detectForVideo(video, timestampMs);
    const rawHands = result.landmarks || [];
    const handednessList = result.handedness || result.handednesses || [];

    const now = performance.now();
    const hands = rawHands.map((landmarks, i) => {
      // reset smoothing if this hand slot went quiet for a while (avoids
      // a stale hand's position "dragging" a newly-appeared hand)
      const lastSeen = this.lastSeenAt.get(i) || 0;
      if (now - lastSeen > 350) {
        this.smoothers.get(i)?.reset();
      }
      this.lastSeenAt.set(i, now);

      if (!this.smoothers.has(i)) this.smoothers.set(i, new EmaSmoother(0.45));
      const flat = [];
      for (const p of landmarks) { flat.push(p.x, p.y); }
      const smoothed = this.smoothers.get(i).smooth(flat);
      const points = [];
      for (let k = 0; k < landmarks.length; k++) {
        points.push({ x: smoothed[k * 2], y: smoothed[k * 2 + 1], z: landmarks[k].z });
      }
      return {
        landmarks: points,
        handedness: handednessList[i]?.[0]?.categoryName || 'Right'
      };
    });

    return hands;
  }

  close() {
    this.landmarker?.close?.();
    this.landmarker = null;
    this.ready = false;
  }
}

/* -------------------------------------------------------------------- */
/*  Gesture recognition — operates on normalized (0..1) landmarks        */
/* -------------------------------------------------------------------- */

export class GestureTracker {
  constructor() {
    this.states = new Map(); // handKey -> per-hand gesture state
  }

  _state(key) {
    if (!this.states.has(key)) {
      this.states.set(key, {
        open: false,
        openHoldStart: 0,
        lastBurstAt: 0,
        pinched: false,
        pinchStartAt: 0,
        palmHistory: [],
        lastSwipeAt: 0
      });
    }
    return this.states.get(key);
  }

  reset(key) {
    this.states.delete(key);
  }

  /** hand: { landmarks, handedness }, key: stable id per hand slot */
  update(key, hand, nowMs) {
    const lm = hand.landmarks;
    const st = this._state(key);

    const handScale = dist(lm[LM.WRIST].x, lm[LM.WRIST].y, lm[LM.MIDDLE_MCP].x, lm[LM.MIDDLE_MCP].y) || 0.001;

    // --- open palm: count extended fingers (tip farther from wrist than pip) ---
    let extended = 0;
    for (const [mcp, pip, tip] of FINGER_CHAINS) {
      const dPip = dist(lm[LM.WRIST].x, lm[LM.WRIST].y, lm[pip].x, lm[pip].y);
      const dTip = dist(lm[LM.WRIST].x, lm[LM.WRIST].y, lm[tip].x, lm[tip].y);
      if (dTip > dPip * 1.08) extended++;
    }
    const isOpen = extended >= 3;

    const openEdgeIn = isOpen && !st.open;
    st.open = isOpen;

    // --- pinch: thumb tip vs index tip distance, scaled by hand size ---
    const pinchDist = dist(lm[LM.THUMB_TIP].x, lm[LM.THUMB_TIP].y, lm[LM.INDEX_TIP].x, lm[LM.INDEX_TIP].y) / handScale;
    const isPinched = pinchDist < 0.55;
    const wasPinched = st.pinched;
    st.pinched = isPinched;
    const pinchEdgeIn = isPinched && !wasPinched;
    const pinchEdgeOut = !isPinched && wasPinched;

    const midX = (lm[LM.THUMB_TIP].x + lm[LM.INDEX_TIP].x) / 2;
    const midY = (lm[LM.THUMB_TIP].y + lm[LM.INDEX_TIP].y) / 2;

    // --- palm center + swipe velocity ---
    const palmX = (lm[LM.WRIST].x + lm[LM.INDEX_MCP].x + lm[LM.MIDDLE_MCP].x + lm[LM.RING_MCP].x + lm[LM.PINKY_MCP].x) / 5;
    const palmY = (lm[LM.WRIST].y + lm[LM.INDEX_MCP].y + lm[LM.MIDDLE_MCP].y + lm[LM.RING_MCP].y + lm[LM.PINKY_MCP].y) / 5;

    st.palmHistory.push({ x: palmX, y: palmY, t: nowMs });
    while (st.palmHistory.length > 6) st.palmHistory.shift();

    let swipe = null;
    if (st.palmHistory.length >= 3) {
      const first = st.palmHistory[0];
      const last = st.palmHistory[st.palmHistory.length - 1];
      const dt = (last.t - first.t) / 1000;
      if (dt > 0.02) {
        const vx = (last.x - first.x) / dt;
        const vy = (last.y - first.y) / dt;
        const speed = Math.hypot(vx, vy);
        if (speed > 1.6 && nowMs - st.lastSwipeAt > 90) {
          swipe = { x: palmX, y: palmY, dirX: vx / speed, dirY: vy / speed, speed };
          st.lastSwipeAt = nowMs;
        }
      }
    }

    // sustained-open periodic re-bloom (every ~900ms while palm stays open)
    let burst = false;
    if (isOpen) {
      if (openEdgeIn) { st.openHoldStart = nowMs; st.lastBurstAt = 0; }
      if (nowMs - st.lastBurstAt > 900) {
        burst = true;
        st.lastBurstAt = nowMs;
      }
    }

    return {
      isOpen,
      openBurst: burst,
      isPinched,
      pinchStart: pinchEdgeIn,
      pinchEnd: pinchEdgeOut,
      pinchMid: { x: midX, y: midY },
      palm: { x: palmX, y: palmY },
      swipe,
      handScale
    };
  }
}
