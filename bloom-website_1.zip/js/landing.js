// landing.js — the landing screen's signature moment: a single flower
// slowly unfurling from a bud, on a loop, with ambient floating petals
// and dust drifting past. Purely decorative, previews the site's core
// interaction before the camera ever opens.

import { rand } from './util.js';

export class LandingScene {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.particles = [];
    this.t0 = performance.now();
    this.parallax = { x: 0, y: 0, tx: 0, ty: 0 };
    this.running = false;
    this._resize = this._resize.bind(this);
    this._onMove = this._onMove.bind(this);
    this._resize();
    window.addEventListener('resize', this._resize);
    window.addEventListener('pointermove', this._onMove, { passive: true });
    this._seedAmbient();
  }

  _resize() {
    const { canvas, dpr } = this;
    this.w = canvas.clientWidth;
    this.h = canvas.clientHeight;
    canvas.width = this.w * dpr;
    canvas.height = this.h * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  _onMove(e) {
    const nx = (e.clientX / window.innerWidth) * 2 - 1;
    const ny = (e.clientY / window.innerHeight) * 2 - 1;
    this.parallax.tx = nx * 10;
    this.parallax.ty = ny * 6;
  }

  _seedAmbient() {
    this.particles = [];
    const count = Math.min(26, Math.floor((this.w * this.h) / 42000) + 14);
    for (let i = 0; i < count; i++) {
      this.particles.push({
        x: rand(0, this.w),
        y: rand(0, this.h),
        r: rand(1.4, 4.2),
        speed: rand(6, 18),
        drift: rand(-8, 8),
        phase: rand(0, Math.PI * 2),
        sway: rand(10, 26),
        opacity: rand(0.15, 0.55),
        kind: Math.random() < 0.35 ? 'petal' : 'dust'
      });
    }
  }

  start() {
    if (this.running) return;
    this.running = true;
    const loop = (now) => {
      if (!this.running) return;
      this._frame(now);
      this._raf = requestAnimationFrame(loop);
    };
    this._raf = requestAnimationFrame(loop);
  }

  stop() {
    this.running = false;
    if (this._raf) cancelAnimationFrame(this._raf);
  }

  _drawPetalShape(ctx, size, colorInner, colorOuter) {
    const grad = ctx.createLinearGradient(0, 0, 0, -size);
    grad.addColorStop(0, colorInner);
    grad.addColorStop(1, colorOuter);
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.bezierCurveTo(size * 0.5, -size * 0.28, size * 0.3, -size * 0.92, 0, -size);
    ctx.bezierCurveTo(-size * 0.3, -size * 0.92, -size * 0.5, -size * 0.28, 0, 0);
    ctx.fill();
  }

  _frame(now) {
    const { ctx, w, h } = this;
    ctx.clearRect(0, 0, w, h);

    this.parallax.x += (this.parallax.tx - this.parallax.x) * 0.04;
    this.parallax.y += (this.parallax.ty - this.parallax.y) * 0.04;

    // ambient floating petals / dust
    const dt = 1 / 60;
    for (const p of this.particles) {
      p.y -= p.speed * dt;
      p.phase += dt * 0.8;
      p.x += Math.sin(p.phase) * p.drift * dt;
      if (p.y < -20) {
        p.y = h + 20;
        p.x = rand(0, w);
      }
      ctx.save();
      ctx.globalAlpha = p.opacity;
      ctx.translate(p.x + this.parallax.x * 0.3, p.y + this.parallax.y * 0.3);
      if (p.kind === 'petal') {
        ctx.rotate(p.phase);
        this._drawPetalShape(ctx, p.r * 4.5, 'rgba(255,217,232,0.9)', 'rgba(243,166,196,0.15)');
      } else {
        ctx.fillStyle = 'rgba(232,196,104,0.9)';
        ctx.beginPath();
        ctx.arc(0, 0, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // signature bloom, centered slightly above middle, looping unfurl
    const cx = w / 2 + this.parallax.x;
    const cy = h * 0.42 + this.parallax.y;
    const cycle = 6200;
    const elapsed = (now - this.t0) % cycle;
    const openT = Math.min(elapsed / 2600, 1); // 0..1 unfurl
    const holdEnd = 4200;
    const eased = 1 - Math.pow(1 - openT, 3);

    ctx.save();
    ctx.translate(cx, cy);

    // soft glow behind the bloom
    const glowR = 60 + eased * 130;
    const glow = ctx.createRadialGradient(0, 0, 0, 0, 0, glowR);
    glow.addColorStop(0, 'rgba(243,166,196,0.22)');
    glow.addColorStop(1, 'rgba(243,166,196,0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(0, 0, glowR, 0, Math.PI * 2);
    ctx.fill();

    // stem
    ctx.save();
    ctx.globalAlpha = 0.5;
    ctx.strokeStyle = 'rgba(180,150,120,0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 20);
    ctx.quadraticCurveTo(10, 80, -6, 150);
    ctx.stroke();
    ctx.restore();

    const petals = 8;
    const maxLen = 46 + eased * 30;
    const sway = elapsed > holdEnd ? Math.sin((elapsed - holdEnd) * 0.002) * 4 : 0;
    for (let i = 0; i < petals; i++) {
      const angle = (Math.PI * 2 * i) / petals + sway * 0.01;
      const localT = Math.max(0, Math.min(1, (openT - i * 0.02) * 1.3));
      const localEase = 1 - Math.pow(1 - localT, 3);
      ctx.save();
      ctx.rotate(angle);
      ctx.scale(localEase, localEase);
      ctx.globalAlpha = 0.85 * localEase + 0.15;
      this._drawPetalShape(ctx, maxLen, '#ffe3ee', '#f3a6c4');
      ctx.restore();
    }

    // center
    ctx.save();
    ctx.globalAlpha = Math.min(eased * 1.4, 1);
    const cGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, 14);
    cGrad.addColorStop(0, '#fff3c9');
    cGrad.addColorStop(1, '#e8c468');
    ctx.fillStyle = cGrad;
    ctx.beginPath();
    ctx.arc(0, 0, 12 + eased * 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.restore();
  }

  destroy() {
    this.stop();
    window.removeEventListener('resize', this._resize);
    window.removeEventListener('pointermove', this._onMove);
  }
}
